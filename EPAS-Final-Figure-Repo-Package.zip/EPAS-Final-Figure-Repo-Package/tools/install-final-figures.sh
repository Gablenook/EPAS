#!/usr/bin/env bash
set -euo pipefail

mkdir -p figures/png
cp -R EPAS-Final-Figure-Repo-Package/figures/png/*.png figures/png/

git add figures/png
git commit -m "docs(epas): add final controlled figure PNG set"
git push
