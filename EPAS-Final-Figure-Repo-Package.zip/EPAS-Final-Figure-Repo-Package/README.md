# EPAS Final Controlled Figure Set

This package contains the accepted controlled-layout PNG figure set for the EPAS v2.0 publication draft.

## Contents

- `figures/png/figure-01-edge-platform-context-model.png`
- `figures/png/figure-02-platform-product-deployment-hierarchy.png`
- `figures/png/figure-03-platform-technology-map.png`
- `figures/png/figure-04-commissioning-flow.png`
- `figures/png/figure-05-configurable-workflow-model.png`
- `figures/png/figure-06-runtime-transaction-lifecycle.png`
- `figures/png/figure-07-custody-state-model.png`
- `figures/png/figure-08-transaction-journal-recovery-model.png`
- `figures/png/figure-09-hardware-abstraction-layer.png`
- `figures/png/figure-10-local-persistence-model.png`
- `figures/png/figure-11-edge-to-backend-responsibility-split.png`
- `figures/png/figure-12-cross-cutting-services-fabric.png`
- `figures/png/figure-13-security-trust-boundary-model.png`
- `figures/png/figure-14-administrative-operations-model.png`
- `figures/png/figure-15-deployment-package-model.png`
- `figures/png/figure-16-commercial-reuse-flywheel.png`
- `figures/png/figure-17-platform-evolution-roadmap.png`
- `figures/png/figure-18-ip-strategy-map.png`
- `figures/png/figure-19-epas-strategic-summary.png`

## Install in Repo

From the root of the EPAS repository after unzipping this package:

```bash
mkdir -p figures/png
cp -R figures/png/*.png ./figures/png/

git add figures/png
git commit -m "docs(epas): add final controlled figure PNG set"
git push
```

## Notes

These are flat, publication-ready PNG assets. Canva editability is intentionally deferred.
